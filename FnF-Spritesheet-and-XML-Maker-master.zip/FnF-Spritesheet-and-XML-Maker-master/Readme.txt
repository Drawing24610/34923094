Usage instructions (for all platforms) and installation instructions (for Mac and Linux users) are available on: 
https://github.com/UncertainProd/FnF-Spritesheet-and-XML-Maker

Important: Inside the unzipped folder, click on the application named "XML Generator for Friday Night Funkin", which will be an exe file for windows.

People on other Operating Systems (Mac and Linux) should consider running the application from souce from the github link given above.

The app is written in python and uses the PyQt5 framework.